console.log("1.")
// 1.
const arr = [1, 2, 5, 9, 4, 13, 4, 10];
for (let i = 0; i < arr.length; i++) {
  if (arr[i] === 4) {
    console.log('Есть!');
    break;
  }
}
console.log("2.")
// 2.
let n = 1000;
let num = 0;
while (n >= 50) {
  n /= 2;
  num++;
}
console.log('Результат:', n, 'Кол-во итераций:', num);
console.log("63.")
// 3. 
const resultArray = [];
for (let i = 1; i <= 3; i++) {
  resultArray.push(String(i).repeat(i));
}
console.log(resultArray);
console.log("4.")
// 4.
const originalArray = [1, 2, 3, 4, 5];
const reversedArray = [];
for (let i = originalArray.length - 1; i >= 0; i--) {
  reversedArray.push(originalArray[i]);
}
console.log(reversedArray);
console.log("5.")
// 5.
const months = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
for (const month of months) {
  console.log(month);
}
console.log("6.")
// 6.
const months2 = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
let month = new Date().getMonth() + 1; // Получаем текущий месяц (0-11, поэтому +1)

for (let i = 0; i < months2.length; i++) {
  if (i === month - 1) {
    console.log(%c${months2[i]}, 'font-style: italic;'); // Выводим текущий месяц курсивом
  } else {
    console.log(months2[i]); // Выводим остальные месяцы без изменений
  }
}