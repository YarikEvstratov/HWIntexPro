// 1.
console.log("1.");
const task1Numbers = [2, 4, 5, 7];
const squaredNumbers = task1Numbers.map(num => num ** 2);
console.log(squaredNumbers);

// 2.
console.log("2.");
const task2Strings = ['hello', 'world', 'javascript'];
const reversedStrings = task2Strings.map(str => 
  str.split('').reverse().join('')
);
console.log(reversedStrings);

// 3.
console.log("3.");
const task3Numbers = [3, 5, 7, 9];
const multipliedByIndex = task3Numbers.map((num, index) => num * index);
console.log(multipliedByIndex);

// 4.
console.log("4.");
const task4Numbers = [1, 2, 3, 4];
let sumOfSquares = 0;
task4Numbers.forEach(num => sumOfSquares += num ** 2);
console.log(sumOfSquares);

// 5.
console.log("5.");
const task5Numbers = [-3, 2, -5, 8, -1];
const positiveNumbers = task5Numbers.filter(num => num > 0);
console.log(positiveNumbers);

// 6.
console.log("6.");
const task6Numbers = [7, 12, 5, 20, 4];
const filteredNumbers = task6Numbers.filter((num, index) => num * index < 30);
console.log(filteredNumbers);