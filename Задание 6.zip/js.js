// 1.
console.log("1.");
function sumDigitsUntilSingle(number) {
  const sum = String(number)
    .split('')
    .reduce((acc, digit) => acc + Number(digit), 0);
  
  return sum > 9 ? sumDigitsUntilSingle(sum) : sum;
}
const num = 9875;
console.log(sumDigitsUntilSingle(num));

// 2.
console.log("2.");
const company = {
  name: "Company",
  departments: [
    {
      name: "Разработка",
      projects: [
        { title: "Разработка 1", money: 15000 },
        { title: "Разработка 2", money: 23000 }
      ],
      subDepartments: [
        {
          name: "Мобильная разработка",
          projects: [
            { title: "Мобильная разработка 1", money: 8000 },
            { title: "Мобильная разработка 2", money: 9500 }
          ]
        }
      ]
    },
    {
      name: "Маркетинг",
      projects: [
        { title: "Маркетинг", money: 42000 }
      ],
      subDepartments: [
        {
          name: "Аналитика",
          projects: [
            { title: "Аналитика", money: 17500 }
          ]
        }
      ]
    }
  ]
};

function calculateTotalMoney(structure) {
  let total = 0;

  function processDepartment(department) {
    if (department.projects) {
      total += department.projects.reduce((sum, project) => sum + project.money, 0);
    }
    if (department.subDepartments) {
      department.subDepartments.forEach(processDepartment);
    }
  }
  structure.departments.forEach(processDepartment);
  return total;
}
console.log("Деньги компании: ",  calculateTotalMoney(company));