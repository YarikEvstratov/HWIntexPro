// 0.
console.log("0.");
console.log(typeof 42);
console.log(typeof "Hello");
console.log(typeof true);
console.log(typeof null);
console.log(typeof undefined);
// 1.
console.log("1.")
let var1;
let var2 = null;
var1 = 10;
const result = var1 + var2;
console.log(result);
// 2.
const values = [10, "", "строка", "null", "undefined", null, undefined];
const toString = [];
values.forEach(value => {
    toString.push(String(value));
});
console.log("в строки");
console.log(toString);

const toNumber = [];
values.forEach(value => {
    toNumber.push(Math.abs(Number(value)));
});
console.log("В числа");
console.log(toNumber);

// 3. 
console.log("3.");
console.log("вообще хз как делать)")