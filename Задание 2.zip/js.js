// 1. Полная
console.log("1.");
function checkValue(a) {
    if (a === '1') {
      console.log('Верно');
    } else {
      console.log('Неверно');
    }
  }
  
  checkValue('1');
  checkValue(1);
  checkValue(3);

// 1. Краткая
const a = '1';
console.log(a === '1' ? 'Верно' : 'Неверно');
// 2. Полная
console.log("2.");
function calculate(num1, num2) {
    if (num1 > 0 && num2 > 0) {
      return (num1 + num2) ** 2;
    } else {
      return 2 * num1 * num2;
    }
  }
  
console.log(calculate(2, 3));
console.log(calculate(-1, 5));
// 2. Краткая
num1 = 2;
num2 = 3;
const result = (num1 > 0 && num2 > 0) ? (num1 + num2) ** 2 : 2 * num1 * num2;
console.log(result);
// 3. Полная
console.log("3.")
function compute(a, b) {
    return (a <= 1 && b >= 3) ? a + b : a - b;
  }
  
  console.log(compute(1, 3));
  console.log(compute(0, 6));
  console.log(compute(3, 5));
// 3. Кратко
let a2=1;
let b2=3;
let result2 = (a2 <= 1 && b2 >= 3) ? a2 + b2 : a2 - b2;
console.log(result2);
a2=0;
b2=6;
result2 = (a2 <= 1 && b2 >= 3) ? a2 + b2 : a2 - b2;
console.log(result2);
a2=3;
b2=5;
result2 = (a2 <= 1 && b2 >= 3) ? a2 + b2 : a2 - b2;
console.log(result2);
// 4. Полная
console.log("4.")
function checkConditions(a, b) {
  const condition = (a > 2 && a < 11) || (b >= 6 && b < 14);
  console.log(condition ? 'Верно' : 'Неверно');
}

checkConditions(5, 0);
checkConditions(1, 7);
checkConditions(12, 5);
// 4. Кратко
let a3 = 5;
let b3 = 0;
console.log((a3 > 2 && a3 < 11) || (b3 >= 6 && b3 < 14) ? 'Верно' : 'Неверно');