console.log("1.");
// 1. Обычная
function getDayOfWeek(day) {
    const days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
    return days[day - 1] || 'Неверный день';
  }
console.log(getDayOfWeek(1));
// 1. Стрелочная
const getDayOfWeek2 = (day) => {
    const days = ['Понедельник', 'Вторник', 'Среда', 'Четверг', 'Пятница', 'Суббота', 'Воскресенье'];
    return days[day - 1] || 'Неверный день';
  };
console.log(getDayOfWeek2(2));
console.log("2.");
// 2. Обычная
function isNumberInRange(num) {
    return num > 0 && num < 10;
  }
console.log(isNumberInRange(5));
console.log(isNumberInRange(15));
// 2. Стрелочная
const isNumberInRange2 = num => num > 0 && num < 10;
console.log(isNumberInRange2(5));
console.log(isNumberInRange2(15));
console.log("3.");
// 3. Обычная
function filterNumbers(arr) {
    return arr.filter(isNumberInRange);
  }
const numbers = [1, 5, 12, 3, 8, 10];
console.log(filterNumbers(numbers));
// 3. Стрелочная
const filterNumbers2 = arr => arr.filter(isNumberInRange2);
const numbers2 = [3, 7, 0, 1, 77, 42, 4];
console.log(filterNumbers2(numbers2));
console.log("4.");
// 4. Обычная
function getDivisors(num) {
    const divisors = [];
    for (let i = 1; i <= num; i++) {
      if (num % i === 0){
         divisors.push(i);
        }
    }
    return divisors;
  }
console.log(getDivisors(12));
// 4. Стрелочная
const getDivisorsArrow = (num) => {
    const divisors = [];
    for (let i = 1; i <= num; i++) {
      if (num % i === 0){
         divisors.push(i);
      }
    }
    return divisors;
  };
console.log(getDivisorsArrow(10));